package com.example.dongyinreminder

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.dongyinreminder.databinding.ActivityMainBinding
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("reminder_prefs", MODE_PRIVATE) }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val fmt = DateTimeFormatter.ofPattern("HH:mm")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        NotificationHelper.createChannels(this)
        requestNotificationPermissionIfNeeded()
        resetDailyCountsIfNeeded()
        loadSettings()
        updateDashboard()

        binding.waterStart.setOnClickListener { pickTime("water_start", binding.waterStart, "开始时间") }
        binding.waterEnd.setOnClickListener { pickTime("water_end", binding.waterEnd, "结束时间") }
        binding.moveStart.setOnClickListener { pickTime("move_start", binding.moveStart, "开始时间") }
        binding.moveEnd.setOnClickListener { pickTime("move_end", binding.moveEnd, "结束时间") }

        binding.saveButton.setOnClickListener {
            saveSettings()
            prefs.edit().remove("paused_date").apply()
            ReminderScheduler.scheduleAll(this)
            updateDashboard()
            Toast.makeText(this, "提醒已保存并开启", Toast.LENGTH_SHORT).show()
        }
        binding.pauseTodayButton.setOnClickListener {
            val today = LocalDate.now().toString()
            if (prefs.getString("paused_date", "") == today) {
                prefs.edit().remove("paused_date").apply()
                ReminderScheduler.scheduleAll(this)
                Toast.makeText(this, "今天的提醒已恢复", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putString("paused_date", today).apply()
                ReminderScheduler.cancelAll(this)
                Toast.makeText(this, "今天的提醒已暂停", Toast.LENGTH_SHORT).show()
            }
            updateDashboard()
        }
        binding.testButton.setOnClickListener { ReminderReceiver.showReminder(this, "water", true) }
    }

    override fun onResume() {
        super.onResume()
        resetDailyCountsIfNeeded()
        updateDashboard()
    }

    private fun pickTime(key: String, button: Button, label: String) {
        val fallback = if (key.contains("water")) "08:00" else "09:00"
        val current = prefs.getString(key, fallback) ?: fallback
        val t = runCatching { LocalTime.parse(current) }.getOrDefault(LocalTime.of(8,0))
        TimePickerDialog(this, { _, h, m ->
            val value = LocalTime.of(h, m).format(fmt)
            prefs.edit().putString(key, value).apply()
            button.text = "$label $value"
        }, t.hour, t.minute, true).show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun loadSettings() = with(binding) {
        switchWater.isChecked = prefs.getBoolean("water_enabled", true)
        waterStart.text = "开始时间 " + prefs.getString("water_start", "08:00")
        waterEnd.text = "结束时间 " + prefs.getString("water_end", "22:00")
        waterInterval.setText(prefs.getInt("water_interval", 60).toString())
        waterSound.isChecked = prefs.getBoolean("water_sound", true)
        waterVibrate.isChecked = prefs.getBoolean("water_vibrate", true)
        switchMove.isChecked = prefs.getBoolean("move_enabled", true)
        moveStart.text = "开始时间 " + prefs.getString("move_start", "09:00")
        moveEnd.text = "结束时间 " + prefs.getString("move_end", "18:00")
        moveInterval.setText(prefs.getInt("move_interval", 120).toString())
        moveSound.isChecked = prefs.getBoolean("move_sound", true)
        moveVibrate.isChecked = prefs.getBoolean("move_vibrate", true)
    }

    private fun saveSettings() = with(binding) {
        prefs.edit().putBoolean("water_enabled", switchWater.isChecked)
            .putInt("water_interval", waterInterval.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 60)
            .putBoolean("water_sound", waterSound.isChecked).putBoolean("water_vibrate", waterVibrate.isChecked)
            .putBoolean("move_enabled", switchMove.isChecked)
            .putInt("move_interval", moveInterval.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 120)
            .putBoolean("move_sound", moveSound.isChecked).putBoolean("move_vibrate", moveVibrate.isChecked).apply()
    }

    private fun resetDailyCountsIfNeeded() {
        val today = LocalDate.now().toString()
        if (prefs.getString("count_date", "") != today)
            prefs.edit().putString("count_date", today).putInt("water_done", 0).putInt("move_done", 0).apply()
    }

    private fun updateDashboard() = with(binding) {
        waterProgress.text = "💧 喝水完成 ${prefs.getInt("water_done", 0)} 次"
        moveProgress.text = "🏃 运动完成 ${prefs.getInt("move_done", 0)} 次"
        val paused = prefs.getString("paused_date", "") == LocalDate.now().toString()
        pauseTodayButton.text = if (paused) "恢复今天的所有提醒" else "暂停今天的所有提醒"
        nextReminder.text = if (paused) "今天的提醒已暂停" else "提醒正在按你设置的时间运行"
    }
}
