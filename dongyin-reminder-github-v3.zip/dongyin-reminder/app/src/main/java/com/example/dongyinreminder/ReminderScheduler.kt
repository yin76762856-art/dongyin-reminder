package com.example.dongyinreminder
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object ReminderScheduler {
    fun scheduleAll(context: Context) { cancelAll(context); scheduleNext(context,"water"); scheduleNext(context,"move") }
    fun cancelAll(context: Context) { cancel(context,"water"); cancel(context,"move") }

    fun scheduleNext(context: Context, type: String) {
        val prefs=context.getSharedPreferences("reminder_prefs",Context.MODE_PRIVATE)
        if (prefs.getString("paused_date","")==LocalDate.now().toString() || !prefs.getBoolean("${type}_enabled",true)) return
        val start=parseTime(prefs.getString("${type}_start",if(type=="water")"08:00" else "09:00")!!)
        val end=parseTime(prefs.getString("${type}_end",if(type=="water")"22:00" else "18:00")!!)
        val interval=prefs.getInt("${type}_interval",if(type=="water")60 else 120).coerceAtLeast(1)
        val now=LocalDateTime.now(); val todayStart=now.toLocalDate().atTime(start); val todayEnd=now.toLocalDate().atTime(end)
        val candidate=when {
            now.isBefore(todayStart)->todayStart
            now.isAfter(todayEnd)->todayStart.plusDays(1)
            else->{ val elapsed=java.time.Duration.between(todayStart,now).toMinutes().coerceAtLeast(0); val next=todayStart.plusMinutes((elapsed/interval+1)*interval.toLong()); if(next.isAfter(todayEnd)) todayStart.plusDays(1) else next }
        }
        setAlarm(context,type,candidate.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),false)
    }

    fun snooze(context: Context,type:String,minutes:Int=10)=setAlarm(context,type,System.currentTimeMillis()+minutes*60_000L,true)

    private fun setAlarm(context:Context,type:String,triggerAt:Long,snooze:Boolean){
        val am=context.getSystemService(AlarmManager::class.java); val pi=pendingIntent(context,type,snooze)
        if(android.os.Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,triggerAt,pi)
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,triggerAt,pi)
    }
    private fun pendingIntent(context:Context,type:String,snooze:Boolean=false):PendingIntent{
        val i=Intent(context,ReminderReceiver::class.java).putExtra("type",type).putExtra("snooze_alarm",snooze)
        val base=if(type=="water")1001 else 1002; val code=if(snooze)base+100 else base
        return PendingIntent.getBroadcast(context,code,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun cancel(context:Context,type:String){ val am=context.getSystemService(AlarmManager::class.java); am.cancel(pendingIntent(context,type,false)); am.cancel(pendingIntent(context,type,true)) }
    private fun parseTime(v:String):LocalTime=runCatching{LocalTime.parse(v)}.getOrDefault(LocalTime.of(8,0))
}
