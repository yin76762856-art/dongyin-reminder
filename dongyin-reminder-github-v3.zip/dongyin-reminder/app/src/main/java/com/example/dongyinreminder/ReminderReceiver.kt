package com.example.dongyinreminder
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDate

class ReminderReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        val type=intent.getStringExtra("type")?:"water"
        when(intent.action){
            "com.example.dongyinreminder.DONE"->{markDone(context,type);return}
            "com.example.dongyinreminder.SNOOZE"->{ReminderScheduler.snooze(context,type,10);return}
        }
        val p=context.getSharedPreferences("reminder_prefs",Context.MODE_PRIVATE)
        if(p.getString("paused_date","")!=LocalDate.now().toString()) showReminder(context,type,false)
        if(!intent.getBooleanExtra("snooze_alarm",false)) ReminderScheduler.scheduleNext(context,type)
    }
    companion object{
        private fun actionIntent(c:Context,type:String,action:String,code:Int):PendingIntent=
            PendingIntent.getBroadcast(c,code,Intent(c,ReminderReceiver::class.java).setAction(action).putExtra("type",type),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        fun showReminder(context:Context,type:String,isTest:Boolean){
            val p=context.getSharedPreferences("reminder_prefs",Context.MODE_PRIVATE); val water=type=="water"
            val sound=p.getBoolean(if(water)"water_sound" else "move_sound",true); val vibrate=p.getBoolean(if(water)"water_vibrate" else "move_vibrate",true)
            val channel=if(water)NotificationHelper.WATER_CHANNEL else NotificationHelper.MOVE_CHANNEL
            val title=if(water)"💧 该喝水啦" else "🏃 该活动一下啦"; val text=if(water)"喝几口水，给身体补充水分。" else "站起来走一走，伸展一下身体。"; val base=if(water)3000 else 4000
            val b=NotificationCompat.Builder(context,channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title)
                .setContentText(if(isTest)"$text（测试提醒）" else text).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true)
                .addAction(0,"已完成",actionIntent(context,type,"com.example.dongyinreminder.DONE",base+1))
                .addAction(0,"10分钟后提醒",actionIntent(context,type,"com.example.dongyinreminder.SNOOZE",base+2))
            if(!sound)b.setSilent(true); if(vibrate)b.setVibrate(longArrayOf(0,400,250,400)) else b.setVibrate(longArrayOf(0))
            runCatching{NotificationManagerCompat.from(context).notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),b.build())}
        }
        private fun markDone(context:Context,type:String){
            val p=context.getSharedPreferences("reminder_prefs",Context.MODE_PRIVATE); val today=LocalDate.now().toString(); val same=p.getString("count_date","")==today
            val key=if(type=="water")"water_done" else "move_done"; val current=if(same)p.getInt(key,0) else 0
            val e=p.edit(); if(!same)e.putString("count_date",today).putInt("water_done",0).putInt("move_done",0); e.putInt(key,current+1).apply()
        }
    }
}
