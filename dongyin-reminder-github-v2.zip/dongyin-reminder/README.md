# 动饮提醒 DongYinReminder

一个本地运行的安卓喝水/运动提醒 App。

## 第一版功能
- 喝水提醒、运动提醒分别开关
- 自定义每日开始时间与结束时间
- 自定义提醒间隔
- 每日重复
- 系统通知
- 声音开关
- 震动开关
- 开机后恢复提醒
- 测试提醒
- 设置保存在手机本地，不需要账号和服务器

## 只用手机生成 APK（GitHub Actions）
项目已经包含 `.github/workflows/build-apk.yml`。

上传到 GitHub 仓库后：
1. 打开仓库的 **Actions** 页面。
2. 选择 **Build Android APK**。
3. 点击 **Run workflow**。
4. 构建成功后打开这次运行记录。
5. 在 **Artifacts** 区域下载 `DongYinReminder-debug-apk`。
6. 下载得到 ZIP，解压后就是 `app-debug.apk`。
7. 在安卓手机上允许当前文件管理器/浏览器“安装未知应用”，然后安装 APK。

提示：首次安装可能会看到“未知来源应用”的系统提示，这是因为当前是调试版 APK，并未发布到应用商店。

## GitHub 自动构建说明
- 使用 Java 17
- 使用 Gradle 8.9
- 执行 `:app:assembleDebug`
- APK 输出路径：`app/build/outputs/apk/debug/app-debug.apk`

## 后续计划
- 更友好的提醒音选择
- 稍后提醒（例如 10 分钟后）
- 今日暂停
- 完成记录
- 针对不同安卓品牌优化后台提醒可靠性
