package com.example.dongyinreminder

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.dongyinreminder.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("reminder_prefs", MODE_PRIVATE) }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        NotificationHelper.createChannels(this)
        requestNotificationPermissionIfNeeded()
        loadSettings()

        binding.saveButton.setOnClickListener {
            saveSettings()
            ReminderScheduler.scheduleAll(this)
            Toast.makeText(this, "提醒已保存并开启", Toast.LENGTH_SHORT).show()
        }

        binding.testButton.setOnClickListener {
            ReminderReceiver.showReminder(this, "water", true)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun loadSettings() = with(binding) {
        switchWater.isChecked = prefs.getBoolean("water_enabled", true)
        waterStart.setText(prefs.getString("water_start", "08:00"))
        waterEnd.setText(prefs.getString("water_end", "22:00"))
        waterInterval.setText(prefs.getInt("water_interval", 60).toString())
        waterSound.isChecked = prefs.getBoolean("water_sound", true)
        waterVibrate.isChecked = prefs.getBoolean("water_vibrate", true)
        switchMove.isChecked = prefs.getBoolean("move_enabled", true)
        moveStart.setText(prefs.getString("move_start", "09:00"))
        moveEnd.setText(prefs.getString("move_end", "18:00"))
        moveInterval.setText(prefs.getInt("move_interval", 120).toString())
        moveSound.isChecked = prefs.getBoolean("move_sound", true)
        moveVibrate.isChecked = prefs.getBoolean("move_vibrate", true)
    }

    private fun saveSettings() = with(binding) {
        prefs.edit()
            .putBoolean("water_enabled", switchWater.isChecked)
            .putString("water_start", waterStart.text.toString())
            .putString("water_end", waterEnd.text.toString())
            .putInt("water_interval", waterInterval.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 60)
            .putBoolean("water_sound", waterSound.isChecked)
            .putBoolean("water_vibrate", waterVibrate.isChecked)
            .putBoolean("move_enabled", switchMove.isChecked)
            .putString("move_start", moveStart.text.toString())
            .putString("move_end", moveEnd.text.toString())
            .putInt("move_interval", moveInterval.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 120)
            .putBoolean("move_sound", moveSound.isChecked)
            .putBoolean("move_vibrate", moveVibrate.isChecked)
            .apply()
    }
}
