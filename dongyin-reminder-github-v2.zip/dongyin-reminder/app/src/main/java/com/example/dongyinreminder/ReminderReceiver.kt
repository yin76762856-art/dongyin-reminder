package com.example.dongyinreminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra("type") ?: "water"
        showReminder(context, type, false)
        ReminderScheduler.scheduleNext(context, type)
    }

    companion object {
        fun showReminder(context: Context, type: String, isTest: Boolean) {
            val prefs = context.getSharedPreferences("reminder_prefs", Context.MODE_PRIVATE)
            val isWater = type == "water"
            val soundOn = prefs.getBoolean(if (isWater) "water_sound" else "move_sound", true)
            val vibrateOn = prefs.getBoolean(if (isWater) "water_vibrate" else "move_vibrate", true)
            val channel = if (isWater) NotificationHelper.WATER_CHANNEL else NotificationHelper.MOVE_CHANNEL
            val title = if (isWater) "💧 该喝水啦" else "🏃 该活动一下啦"
            val text = if (isWater) "喝几口水，给身体补充水分。" else "站起来走一走，伸展一下身体。"

            val builder = NotificationCompat.Builder(context, channel)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(if (isTest) "$text（测试提醒）" else text)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            if (!soundOn) builder.setSilent(true)
            if (vibrateOn) builder.setVibrate(longArrayOf(0, 400, 250, 400)) else builder.setVibrate(longArrayOf(0))

            runCatching { NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build()) }
        }
    }
}
