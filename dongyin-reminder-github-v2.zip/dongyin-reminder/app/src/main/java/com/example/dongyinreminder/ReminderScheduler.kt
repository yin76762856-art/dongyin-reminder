package com.example.dongyinreminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object ReminderScheduler {
    fun scheduleAll(context: Context) {
        cancel(context, "water")
        cancel(context, "move")
        scheduleNext(context, "water")
        scheduleNext(context, "move")
    }

    fun scheduleNext(context: Context, type: String) {
        val prefs = context.getSharedPreferences("reminder_prefs", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("${type}_enabled", true)
        if (!enabled) return

        val start = parseTime(prefs.getString("${type}_start", if (type == "water") "08:00" else "09:00")!!)
        val end = parseTime(prefs.getString("${type}_end", if (type == "water") "22:00" else "18:00")!!)
        val interval = prefs.getInt("${type}_interval", if (type == "water") 60 else 120).coerceAtLeast(1)

        val now = LocalDateTime.now()
        var candidate = now.withSecond(0).withNano(0)
        val todayStart = candidate.toLocalDate().atTime(start)
        val todayEnd = candidate.toLocalDate().atTime(end)

        candidate = when {
            now.isBefore(todayStart) -> todayStart
            now.isAfter(todayEnd) -> todayStart.plusDays(1)
            else -> {
                val elapsed = java.time.Duration.between(todayStart, now).toMinutes().coerceAtLeast(0)
                val steps = elapsed / interval + 1
                val next = todayStart.plusMinutes(steps * interval.toLong())
                if (next.isAfter(todayEnd)) todayStart.plusDays(1) else next
            }
        }

        val triggerAt = candidate.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(context, type)
        if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    private fun pendingIntent(context: Context, type: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("type", type)
        val code = if (type == "water") 1001 else 1002
        return PendingIntent.getBroadcast(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun cancel(context: Context, type: String) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context, type))
    }

    private fun parseTime(value: String): LocalTime = runCatching { LocalTime.parse(value) }.getOrDefault(LocalTime.of(8, 0))
}
