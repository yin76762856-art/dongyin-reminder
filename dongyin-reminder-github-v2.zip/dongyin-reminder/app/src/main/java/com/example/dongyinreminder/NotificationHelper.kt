package com.example.dongyinreminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.provider.Settings

object NotificationHelper {
    const val WATER_CHANNEL = "water_reminders"
    const val MOVE_CHANNEL = "move_reminders"

    fun createChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val sound = Settings.System.DEFAULT_NOTIFICATION_URI
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()

        val water = NotificationChannel(WATER_CHANNEL, "喝水提醒", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "喝水提醒通知"
            enableVibration(true)
            setSound(sound, attrs)
        }
        val move = NotificationChannel(MOVE_CHANNEL, "运动提醒", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "运动提醒通知"
            enableVibration(true)
            setSound(sound, attrs)
        }
        nm.createNotificationChannels(listOf(water, move))
    }
}
